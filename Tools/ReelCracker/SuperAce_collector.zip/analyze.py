"""Read captured/spins.jsonl and report RTP / win distribution stats.

Usage:
    python analyze.py                  # full report
    python analyze.py --csv out.csv    # also dump per-spin CSV
    python analyze.py --bet 0.6        # override bet if missing in JSONL
"""

import argparse
import csv
import json
import os
import sys
from collections import Counter

DEFAULT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "captured", "spins.jsonl")


def load_spins(path):
    spins = []
    with open(path, encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                spins.append(json.loads(line))
            except Exception as e:
                print(f"[warn] line {i}: {e}", file=sys.stderr)
    return spins


def fmt_pct(p):
    return f"{p * 100:.4f}%"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", nargs="?", default=DEFAULT_PATH)
    ap.add_argument("--bet", type=float, default=None,
                    help="Override bet for any spin missing it (else skipped from RTP)")
    ap.add_argument("--csv", default=None, help="Write per-spin CSV here")
    args = ap.parse_args()

    if not os.path.isfile(args.path):
        print(f"not found: {args.path}", file=sys.stderr)
        return 1

    spins = load_spins(args.path)
    n = len(spins)
    if n == 0:
        print("no spins")
        return 0

    # --- bet handling ---
    rtp_pairs = []  # (bet, win) where bet is known
    for s in spins:
        bet = s.get("bet") or args.bet
        if bet:
            rtp_pairs.append((float(bet), float(s.get("win") or 0)))

    total_bet = sum(b for b, _ in rtp_pairs)
    total_win = sum(w for _, w in rtp_pairs)
    rtp = total_win / total_bet if total_bet > 0 else None

    # --- hit / bonus rates over all spins ---
    hits = sum(1 for s in spins if (s.get("win") or 0) > 0)
    bonuses = sum(1 for s in spins if s.get("is_bonus"))

    # --- win/bet ratio buckets (per spin) ---
    BUCKETS = [(0, 0, "no win"), (0, 1, "<1x"), (1, 5, "1-5x"),
               (5, 10, "5-10x"), (10, 20, "10-20x (BIG)"),
               (20, 30, "20-30x (MEGA)"), (30, 100, "30-100x (SUPER)"),
               (100, 1000, "100-1000x"), (1000, 10**9, ">=1000x")]

    bucket_counts = Counter()
    for bet, win in rtp_pairs:
        ratio = win / bet if bet > 0 else 0
        for lo, hi, name in BUCKETS:
            if (win == 0 and lo == 0 and hi == 0):
                bucket_counts[name] += 1
                break
            if win > 0 and lo <= ratio < hi:
                bucket_counts[name] += 1
                break

    # --- combo / cascade ---
    combo_dist = Counter(s.get("combo_total", 0) for s in spins)
    plate_dist = Counter(s.get("plate_count", 0) for s in spins)

    # --- biggest wins ---
    by_win = sorted(spins, key=lambda s: float(s.get("win") or 0), reverse=True)[:10]

    # --- bonus details ---
    bonus_spins = [s for s in spins if s.get("is_bonus")]
    avg_fg = (sum(s.get("total_fg") or 0 for s in bonus_spins) / len(bonus_spins)
              if bonus_spins else 0)

    # --- dry streak ---
    longest_dry = cur = 0
    for s in spins:
        if (s.get("win") or 0) == 0:
            cur += 1
            if cur > longest_dry:
                longest_dry = cur
        else:
            cur = 0

    # ====== output ======
    print(f"== SuperAce spin stats ({args.path}) ==")
    print(f"Total spins:      {n:,}")
    if rtp is not None:
        print(f"Spins with bet:   {len(rtp_pairs):,}")
        print(f"Total bet:        {total_bet:,.2f}")
        print(f"Total win:        {total_win:,.2f}")
        print(f"RTP:              {fmt_pct(rtp)}  (theoretical SuperAce ~96.71%)")
    else:
        print("Total bet:        UNKNOWN (use --bet)")
        print(f"Total win:        {sum(s.get('win') or 0 for s in spins):,.2f}")
    print(f"Hit rate:         {fmt_pct(hits / n)}  ({hits:,} winning spins)")
    print(f"Bonus rate:       {fmt_pct(bonuses / n)}  ({bonuses:,} triggers)")
    if bonuses:
        print(f"Avg FG/bonus:     {avg_fg:.2f}")
    print(f"Longest dry:      {longest_dry} spins in a row no win")

    print("\n-- Win/Bet ratio buckets --")
    for _, _, name in BUCKETS:
        c = bucket_counts.get(name, 0)
        if c:
            print(f"  {name:<22s} {c:>6,d}  ({fmt_pct(c / max(len(rtp_pairs), 1))})")

    print("\n-- Combo depth (cascade chains per spin) --")
    for k in sorted(combo_dist):
        c = combo_dist[k]
        print(f"  {k} combos: {c:,d}  ({fmt_pct(c/n)})")

    print("\n-- Plate count (1=normal, >1=Free Game session) --")
    for k in sorted(plate_dist):
        c = plate_dist[k]
        print(f"  {k} plates: {c:,d}  ({fmt_pct(c/n)})")

    print("\n-- Top 10 wins --")
    for s in by_win:
        bet = s.get("bet") or args.bet
        win = float(s.get("win") or 0)
        ratio = (win / bet) if bet else None
        rstr = f"{ratio:7.2f}x" if ratio else "  ?  "
        print(f"  #{s.get('n'):>6}  bet={str(bet):>5}  win={win:>10.2f}  ratio={rstr}  "
              f"FG={s.get('total_fg', 0)}  combos={s.get('combo_total', 0)}")

    if args.csv:
        with open(args.csv, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["n", "ts", "bet", "win", "ratio", "is_bonus", "total_fg",
                        "plate_count", "combo_total"])
            for s in spins:
                bet = s.get("bet") or args.bet
                win = float(s.get("win") or 0)
                ratio = (win / bet) if bet else ""
                w.writerow([s.get("n"), s.get("ts"), bet, win,
                            f"{ratio:.6f}" if isinstance(ratio, float) else "",
                            int(bool(s.get("is_bonus"))), s.get("total_fg") or 0,
                            s.get("plate_count") or 0, s.get("combo_total") or 0])
        print(f"\nCSV written: {args.csv}")


if __name__ == "__main__":
    sys.exit(main() or 0)
