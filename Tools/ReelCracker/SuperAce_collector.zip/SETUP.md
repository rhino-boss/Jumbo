# SuperAce 資料收集 — 建置與執行手冊

## 1. 需要安裝的軟體

| 軟體 | 版本 | 用途 |
|------|------|------|
| Python | 3.8+ | 跑 mitmproxy 腳本與分析 |
| mitmproxy | 任何近版 | HTTPS 攔截 / 注入 / 紀錄 |
| Chrome 或 Edge | 任何近版 | 跑遊戲 |

```powershell
# 確認 Python
python --version

# 安裝 mitmproxy
pip install mitmproxy
```

---

## 2. 要複製到新電腦的檔案

只需要這 4 個（其他都是探索期的草稿，不用帶）：

```
SuperAce/
├── inject_hook.js     # 注入瀏覽器的 hook，攔截 plaintext
├── save_all.py        # mitmproxy 腳本，注入 + 接收 + 寫 JSONL
├── analyze.py         # 統計分析（RTP / 分佈 / 連敗）
├── migrate.py         # 把舊 captured/plates/*.json 匯入新格式（首次以後不需要）
├── CLAUDE.md          # 專案背景文件（給 Claude 用，可選）
└── data.txt           # 遊戲 game.js 解構參考（除錯時才需要，可選）
```

**不用複製**：`captured/` 整個資料夾。新電腦從零開始累積就好。  
（如果想合併舊資料，把 `captured/spins.jsonl` 跟 `captured/.spin_counter` 兩個檔案也帶過去）

---

## 3. 安裝 mitmproxy CA 憑證（**必做一次**）

沒裝 CA 憑證的話，瀏覽器會擋掉所有 HTTPS 攔截，hook 無法注入。

### 步驟
1. 第一次先空跑一次 mitmproxy：
   ```powershell
   mitmweb
   ```
   這會在 `~/.mitmproxy/` 產生憑證檔。
2. 開瀏覽器到 `http://mitm.it`（要先設好 proxy，看下一節）
3. 下載 Windows .p12 → 雙擊安裝
   - 商店：**本機電腦**
   - 憑證存放區：**受信任的根憑證授權單位**
4. 重開瀏覽器
5. Ctrl+C 結束 mitmproxy

---

## 4. 設定瀏覽器 / 系統 proxy

mitmproxy 預設監聽 `127.0.0.1:8080`。

### Windows 系統 proxy（最簡單）
1. 設定 → 網路與網際網路 → Proxy
2. 「使用 Proxy 伺服器」開啟
3. 位址 `127.0.0.1`，連接埠 `8080`
4. 儲存

### 或用 Chrome 自帶（不影響其他應用程式）
裝個擴充套件 `Proxy SwitchyOmega`，設定一個 `mitmproxy` profile 指向 `127.0.0.1:8080`。

> ⚠️ 不用 mitmproxy 時記得**關掉 proxy**，不然其他網站都會連不上。

---

## 5. 第一次執行 — 驗證流程

### 5.1 啟動 mitmproxy（在 SuperAce 資料夾下）
```powershell
cd C:\path\to\SuperAce
mitmweb -s save_all.py
```

正常會看到：
```
[INIT] spin counter = 0, jsonl = ...captured\spins.jsonl
Web server listening at http://127.0.0.1:8081/
Proxy server listening at *:8080
```

### 5.2 打開遊戲頁面 → 強制重整
- 開啟遊戲 URL
- **Ctrl + Shift + R**（hard refresh，必要！）
- 不要開 DevTools（會觸發反調試）

### 5.3 mitmproxy console 應該看到
```
[INJECT] appended 4XXXB hook to https://...tadagaming.com/.../application.244af.js
```
這代表 hook 注入成功。

### 5.4 轉一把 spin
```
[SPIN #00001] bet=0.60 win=0.00 plates=1 combos=0
```
出現這行 = 全部運作中。

### 5.5 確認資料
`captured\spins.jsonl` 應該每把 spin append 一行 JSON。

---

## 6. 大量收集模式

### 6.1 開 Auto Spin
打開遊戲內建的「Auto Spin」功能，放著跑。

### 6.2 想減少 console 洗版
編輯 `save_all.py` 第一段：
```python
LOG_EVERY = 100   # 改成 100 就每 100 把印一次
```
存檔即生效（mitmproxy 會 reload 腳本，但保險起見可重啟）。

### 6.3 中途隨時看統計
```powershell
python analyze.py
```

### 6.4 出 CSV
```powershell
python analyze.py --csv summary.csv
```

---

## 7. 檔案結構（執行後會自動產生）

```
SuperAce/
├── inject_hook.js
├── save_all.py
├── analyze.py
├── migrate.py
└── captured/                 ← 自動建立
    ├── spins.jsonl           ← 主資料源（一行一把 spin）
    ├── .spin_counter         ← 計數器持久化
    └── (其他靜態檔)            ← 遊戲資源備份，不重要
```

---

## 8. 常見問題

| 症狀 | 原因 / 解法 |
|------|------------|
| 沒看到 `[INJECT]` 訊息 | (1) 沒 hard refresh   (2) CA 憑證沒裝   (3) proxy 沒開 |
| 看到 `[INJECT]` 但沒 `[SPIN]` | (1) hook 沒等到 Board class — 等 30 秒再轉 spin   (2) 遊戲版本變動使 `cc.js.getClassByName('Board')` 抓不到 — 把 `inject_hook.js` 的 fallback 邏輯打開 |
| `bet=None` | request 格式跟之前不一樣，`_extract_bet_from_req` 抓不到。重看 spin 請求 hex 並調整偏移量 |
| 遊戲跑不起來 | 把系統 proxy 關掉重試；憑證沒裝瀏覽器才會擋 |
| 想重置統計 | 刪掉 `captured/spins.jsonl` 跟 `captured/.spin_counter` 兩個檔案 |

---

## 9. 給未來的 Claude session

如果後續要請 Claude 接手繼續分析，先讓它讀：
- `CLAUDE.md` — 遊戲背景與 protobuf schema
- `SETUP.md` (本檔) — 工作流程
- `captured/spins.jsonl` — 實際資料
