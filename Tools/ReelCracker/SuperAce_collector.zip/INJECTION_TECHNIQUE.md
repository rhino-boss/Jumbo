# Cocos Creator 3.x 遊戲 JS 注入完整說明

這份文件記錄了在不開 DevTools 的情況下，如何透過 mitmproxy 攔截並注入
JavaScript，讓遊戲自動回傳解密後的 spin 結果。整套流程可以套用到任何
Cocos Creator 3.x 打包的 HTML5 遊戲。

---

## 一、為什麼不能用 DevTools

第一個反直覺的前提：**開 DevTools 會讓遊戲掛掉**。

SuperAce 在 `GameConst` 模組（data.txt L10910）裡有兩層防護：

1. **debugger 語句** — 在 obfuscated code 的特定位置插入 `debugger;`，
   只要 DevTools 開著就會中斷執行。
2. **Timing check** — 用 `Date.now()` 或 `performance.now()` 計算兩次
   呼叫之間的時間差，DevTools 讓 JS 執行變慢時就觸發 `_0x4e2737()`
   強制關閉視窗。

**結論：必須在頁面載入之前、由外部把 hook 植入，遊戲自己跑起來後再也
不需要人介入。mitmproxy 是唯一的切入點。**

---

## 二、Cocos Creator 3.x 的打包結構

理解這個才能找到注入點。

### 2-1. 模組系統

Cocos Creator 3.x 用 **SystemJS** 格式打包，每個 JS 檔看起來像：

```javascript
System.register(["./application.244af.js"], function (_export, _context) {
  ...
});
```

所有模組在執行前都得先 `System.import()`，所以有**明確的載入順序**。

### 2-2. 典型載入順序

```
polyfills.bundle.XXX.js     ← 瀏覽器相容補丁，最早執行
system.bundle.XXX.js        ← SystemJS loader 本體
index.XXXX.js               ← 入口：取得 canvas，呼叫 Application
application.XXXX.js         ← Application class：呼叫 cc.game.init/run
  └── cc.game.init()        ← 引擎初始化
      └── 載入 game bundle  ← 遊戲邏輯（Board/Wheel 等 class 都在這裡）
```

### 2-3. 檔名格式

Cocos 打包時會根據內容產生 content hash，所以：

```
application.244af.js    ← 244af 是 hash，換版本或重打包就會變
assets/game/index.ce899.js ← 遊戲主 bundle（887KB 的 data.txt）
```

---

## 三、找到正確的注入點

### 目標條件

注入的 JS 必須滿足：
1. **早於遊戲 bundle 執行**：這樣才能在 Board class 被建立之前架好 hook
2. **檔案要小**：大檔注入之後，瀏覽器 parse + 執行時間長，容易出問題
3. **有明確特徵**：能在 mitmproxy 裡用字串 match 識別

### 為什麼選 `application.XXXX.js`

對比幾個候選：

| 檔案 | 大小 | 執行時機 | 是否適合 |
|------|------|----------|---------|
| `polyfills.bundle.js` | 大 | 最早 | 可以，但找不到 `cc` 物件 |
| `system.bundle.js` | 中 | 早 | 可以，但 `cc` 還沒初始化 |
| **`application.XXXX.js`** | **小（83行）** | **早** | **✅ 最佳** |
| `assets/game/index.js` | 887KB | 晚 | 太晚，且是目標模組 |

`application.js` 定義 `Application` class，它的 `init()` 方法在 `cc.game.init()` 之前被呼叫，這時候 `cc` 物件已經傳進來，但遊戲 bundle 還沒跑。**在這個時間窗口 hook 最安全。**

### 如何在新遊戲找到對應檔案

1. 開 mitmweb（`mitmweb -s save_all.py` 的空跑版）
2. 開遊戲，看 mitmweb 的 flow list
3. 過濾 `~t javascript`，按時間排序
4. 找那個：**最早載入、最小（<5KB）、內容包含 `cc.game.init` 或 `application`** 的 JS
5. 或直接在 `save_all.py` 用 `print(url, len(content))` 把所有 JS URL 印出來，肉眼找

---

## 四、mitmproxy 攔截並修改 JS 回應

### 核心程式碼

```python
def response(flow: http.HTTPFlow):
    url = flow.request.url
    ct = flow.response.headers.get("content-type", "")

    # 1. 識別目標檔案
    if "application." in url and ".js" in url and "javascript" in ct:
        hook = open("inject_hook.js", "rb").read()
        
        # 2. 在原始內容後面追加 hook
        flow.response.content = flow.response.content + b"\n;\n" + hook
        
        # 3. 強制不快取（關鍵！不做這步瀏覽器會吃快取版本）
        flow.response.headers["Cache-Control"] = "no-store, no-cache"
        flow.response.headers.pop("ETag", None)
        flow.response.headers.pop("Last-Modified", None)
```

**mitmproxy 會自動修正 `Content-Length`**，不用手動計算。

### 為什麼追加在尾端而不是頭部

- 追加在 `});` 後面：原始的 `System.register(...)` 完整執行，不破壞模組載入
- Hook 是獨立的 IIFE，不依賴 `System.register` 的 export 機制
- 如果插在頭部，`System.register` 的閉包變數還沒初始化可能出問題

---

## 五、Hook 的設計與運作

### 5-1. IIFE + 防止重複執行

```javascript
;(function () {
  'use strict';
  if (window.__SAH__) return;   // 防止重複注入（hot reload 情境）
  window.__SAH__ = true;
  // ... 其他邏輯
})();
```

用 IIFE 是因為 hook 被 append 在模組後面，不在任何 `System.register`
的 `execute()` 函數裡，會**立即執行**。

### 5-2. 等待 cc 物件 + 輪詢 Board class

```javascript
var iv = setInterval(function () {
  if (typeof cc === 'undefined' || !cc.js) return;  // cc 還沒準備好

  var Board = cc.js.getClassByName('Board');
  if (!Board || !Board.prototype) return;            // Board 還沒註冊
  Board.__sah_wrapped = true;
  clearInterval(iv);

  // 在這裡做 wrap
}, 500);
```

**為什麼 `cc.js.getClassByName('Board')` 能找到？**

Cocos 用 `_RF.push({}, "<uuid>", "<ClassName>")` 把每個 class 的原始名稱
存到 `cc.js._registeredClassNames` 這個字典裡。Obfuscator 會把變數名改掉
（`_0x1234`），但**字串 literal 不會被改**，所以 class 的中繼資料保留了
原始名稱。

這個行為適用於所有用 `cc.Class({})` 或 `@ccclass` 裝飾器定義的 class。

### 5-3. Method 名稱同樣被保留

```javascript
if (typeof proto.resolveSpinResponse === 'function') {
  var orig = proto.resolveSpinResponse;
  proto.resolveSpinResponse = function () { ... };
}
```

Cocos 的 Method name 在 prototype 上是以字串 key 存放的，
obfuscator 只改宣告端的變數名，**object 的 property key 不會改**。

所以只要從 DevTools（第一次調試）或源碼分析知道方法叫什麼名字，
之後就可以直接用名字 wrap，不需要反混淆。

### 5-4. Fallback：掃全部 method 找形狀吻合的 arg

如果方法名被改了（或不確定叫什麼），可以掃 prototype 所有 function，
對每個 call 的 arg 做型別檢查：

```javascript
Object.getOwnPropertyNames(proto).forEach(function (mname) {
  var orig = proto[mname];
  if (typeof orig !== 'function') return;
  proto[mname] = function () {
    for (var i = 0; i < arguments.length; i++) {
      var a = arguments[i];
      if (a && Array.isArray(a.plate)) {     // 找形狀：有 .plate 陣列的物件
        send({ method: mname, data: a });
        break;
      }
    }
    return orig.apply(this, arguments);
  };
});
```

**這個 fallback 不需要知道方法名稱**，只需要知道 payload 的 schema（`a.plate` 是陣列）。

---

## 六、資料回傳：繞過 CORS 的技巧

Hook 拿到 plaintext 之後，必須把它傳出來給 mitmproxy。

### 問題

直接 POST 到 `localhost:8080` 會被 CORS 擋（`Origin: https://game.com` ≠ `http://localhost`）。

### 解法：POST 到同一個 game server 的假路徑

```javascript
fetch(plateHost + '/__plate_log/spin', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(payload),
  mode: 'cors',
  credentials: 'omit',
});
```

`plateHost` 是從 XHR URL 抽出來的 origin（`https://api.tadagaming.com`）。
Request 送到跟 game API 同一個 server → **瀏覽器認為是 same-origin 的
sub-resource，沒有 CORS 問題**。

Mitmproxy 在 `request()` hook 攔截這個 request，回傳假 200，不讓它真的
到達 server：

```python
def request(flow: http.HTTPFlow):
    if "/__plate_log/" in flow.request.path:
        body = flow.request.content                 # 拿到 plaintext
        save_to_jsonl(body)
        flow.response = http.Response.make(         # 假回應，不 forward
            200, b'{"ok":true}',
            {"Access-Control-Allow-Origin": "*"}    # 讓 fetch Promise 成功 resolve
        )
```

### OPTIONS Preflight 處理

瀏覽器發 `Content-Type: application/json` 之前會先送 OPTIONS preflight。
需要在 mitmproxy 的 `request()` 裡特判：

```python
if flow.request.method == "OPTIONS":
    flow.response = http.Response.make(204, b"", {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST,GET,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
    })
    return
```

---

## 七、應用到下一個遊戲的 Checklist

### Step 1：確認是不是 Cocos Creator

- 看 network requests，有沒有 `cc.d51d0.js` 或類似的 Cocos 引擎 bundle
- HTML 裡有沒有 `<canvas id="GameCanvas">`
- JS 裡有沒有 `System.register()`

### Step 2：找載入順序

```python
# 在 save_all.py 的 response() 加這幾行暫時觀察
if "javascript" in ct:
    print(f"JS: {len(flow.response.content):>8}B  {url}")
```

重新整理頁面，觀察 JS 按大小和時間排序，找最小的那個早期 JS。

### Step 3：找 Application class / cc.game.init 位置

在小型早期 JS 裡搜：`cc.game.init`、`cc.game.run`、`Application`。
找到了就是注入點。

### Step 4：找目標 Class 名稱

兩種方法：

**方法 A（靜態分析）**：grep 遊戲 bundle 找 `_RF.push`
```
_RF.push({}, "xxxxxxxx", "ClassName")
```
這就是遊戲裡所有 Cocos class 的名字清單。找跟「spin/result/board/reel」
相關的名字。

**方法 B（動態）**：在 hook 裡先列出所有 class
```javascript
if (typeof cc !== 'undefined' && cc.js && cc.js._registeredClassNames) {
  var names = Object.keys(cc.js._registeredClassNames);
  fetch(plateHost + '/__plate_log/__classes', {
    method: 'POST',
    body: JSON.stringify(names.filter(n => /spin|board|reel|slot/i.test(n)))
  });
}
```

### Step 5：找 spin response 方法

知道 class 名之後，用 Fallback 掃 method（見 5-4），觀察哪個 method 在
轉 spin 之後會被呼叫、arg 是什麼形狀。第一把 spin 之後會收到一堆
`/__plate_log/` 的 POST，看哪個 label 有 spin 結果。

### Step 6：確認 protobuf / response schema

不同遊戲的 server payload 結構不同。用 Fallback 拿到第一個 arg 後，
`JSON.stringify` 整個物件，看頂層 key 是什麼，再決定要 filter 哪個欄位。

---

## 八、方法論總結

```
┌─────────────────────────────────────────────────────────────┐
│  核心原則：找到正確的「時間窗口」+ 「身份冒充同 origin」     │
│                                                             │
│  時間窗口：注入點在「引擎就緒」之後、「遊戲 class 載入」前  │
│            → application.XXXX.js 的 append 位置            │
│                                                             │
│  身份冒充：hook 回傳資料用 fetch 到同一個 game server 域名  │
│            mitmproxy 在中間攔截，server 永遠收不到          │
│                                                             │
│  利用框架特性：Cocos cc.js.getClassByName() 保留原始名稱   │
│                不需要反混淆，直接用字串找 class 跟 method   │
└─────────────────────────────────────────────────────────────┘
```

這套方法的限制：
- 只適用於 **HTML5 / WebGL 遊戲**（不適用 native app）
- 只適用於 **mitmproxy 能攔截的流量**（需要安裝 CA 憑證）
- 遊戲如果用 **WebAssembly（WASM）** 跑核心邏輯，class 不在 JS 層，
  就必須找 WASM export 的 function，難度大幅提升
