"""Migrate captured/plates/*.json (old per-file format) into captured/spins.jsonl.

Skips empty files (CORS preflight) and non-spin labels (setStartBoard).
Idempotent: appends only spins not already in spins.jsonl (dedup by ts + win).
"""

import json
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
PLATES_DIR = os.path.join(ROOT, "captured", "plates")
JSONL = os.path.join(ROOT, "captured", "spins.jsonl")
COUNTER = os.path.join(ROOT, "captured", ".spin_counter")


def load_existing_keys():
    keys = set()
    last_n = 0
    if not os.path.isfile(JSONL):
        return keys, last_n
    with open(JSONL, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                keys.add((rec.get("ts"), round(float(rec.get("win") or 0), 6)))
                if rec.get("n", 0) > last_n:
                    last_n = rec["n"]
            except Exception:
                pass
    return keys, last_n


def summarize(plate_obj):
    plate_list = plate_obj.get("plate") or []
    total_win = 0.0
    for p in plate_list:
        try:
            total_win += float(p.get("win") or 0)
        except Exception:
            pass
    is_bonus = any(bool(p.get("isBonus")) for p in plate_list)
    total_fg = 0
    for p in plate_list:
        try:
            v = int(p.get("totalFreeSpin") or 0)
            if v > total_fg:
                total_fg = v
        except Exception:
            pass
    return {
        "win": round(total_win, 6),
        "is_bonus": is_bonus,
        "total_fg": total_fg,
        "plate_count": len(plate_list),
        "combo_total": sum(len(p.get("combo") or []) for p in plate_list),
    }


def main():
    if not os.path.isdir(PLATES_DIR):
        print(f"no plates dir: {PLATES_DIR}")
        return 1

    existing, last_n = load_existing_keys()
    print(f"existing JSONL records: {len(existing)} (last n = {last_n})")

    files = sorted(f for f in os.listdir(PLATES_DIR) if f.endswith(".json"))
    skipped_empty = 0
    skipped_nonspin = 0
    skipped_dup = 0
    written = 0

    n = last_n
    rows = []

    for fname in files:
        path = os.path.join(PLATES_DIR, fname)
        if os.path.getsize(path) == 0:
            skipped_empty += 1
            continue
        try:
            with open(path, encoding="utf-8") as f:
                doc = json.loads(f.read())
        except Exception as e:
            print(f"  parse fail {fname}: {e}")
            continue

        # old format: {"label": "plate", "ts":..., "data": {"cls","method","arg_index","value": <plate>}}
        data = doc.get("data") or {}
        method = data.get("method", "")
        plate_obj = data.get("value") or {}

        if not isinstance(plate_obj.get("plate"), list):
            skipped_nonspin += 1
            continue

        ts = doc.get("ts") or 0
        summary = summarize(plate_obj)

        key = (ts, summary["win"])
        if key in existing:
            skipped_dup += 1
            continue
        existing.add(key)

        n += 1
        rec = {
            "n": n,
            "ts": ts,
            "bet": None,
            **summary,
            "method": method,
            "plate": plate_obj,
            "_migrated": fname,
        }
        rows.append(rec)
        written += 1

    if rows:
        with open(JSONL, "a", encoding="utf-8") as f:
            for rec in rows:
                f.write(json.dumps(rec, ensure_ascii=False, separators=(",", ":")) + "\n")
        with open(COUNTER, "w") as f:
            f.write(str(n))

    print(f"written: {written}")
    print(f"skipped (empty preflight): {skipped_empty}")
    print(f"skipped (non-spin / setStartBoard): {skipped_nonspin}")
    print(f"skipped (dedup): {skipped_dup}")
    print(f"new counter: {n}")


if __name__ == "__main__":
    sys.exit(main() or 0)
