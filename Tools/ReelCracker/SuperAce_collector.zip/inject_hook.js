/* SuperAce plaintext capture hook - injected by save_all.py into application.244af.js */
;(function () {
  'use strict';
  if (window.__SAH__) return;
  window.__SAH__ = true;

  var TAG = '[SAH]';
  var plateHost = null;

  /* ---------- 1. Detect game host from any tadagaming-domain XHR ---------- */
  var _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, url) {
    if (!plateHost && typeof url === 'string' && url.indexOf('/fullhouse/') !== -1) {
      try { plateHost = new URL(url, window.location.href).origin; } catch (e) {}
    }
    return _open.apply(this, arguments);
  };

  /* ---------- 2. Send plaintext payload to mitmproxy ---------- */
  function send(payload) {
    if (!plateHost) return;
    try {
      fetch(plateHost + '/__plate_log/spin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload, replacer),
        mode: 'cors',
        credentials: 'omit',
        keepalive: true,
      }).catch(function () {});
    } catch (e) {}
  }

  function replacer(k, v) {
    if (v instanceof Uint8Array) return Array.from(v);
    if (typeof v === 'bigint') return v.toString();
    if (v && typeof v === 'object' && v.constructor && v.constructor.name === 'Long') {
      return { __long__: { low: v.low, high: v.high, unsigned: v.unsigned } };
    }
    return v;
  }

  /* ---------- 3. Wait for Board class, wrap resolveSpinResponse by name ---------- */
  var attempts = 0;
  var iv = setInterval(function () {
    attempts++;
    if (attempts > 1200) { clearInterval(iv); return; } // 10 min cap

    if (typeof cc === 'undefined' || !cc.js || !cc.js.getClassByName) return;

    var Board = null;
    try { Board = cc.js.getClassByName('Board'); } catch (e) {}
    if (!Board || !Board.prototype || Board.__sah_wrapped) return;
    Board.__sah_wrapped = true;
    clearInterval(iv);

    var proto = Board.prototype;
    var wrappedName = null;

    // Preferred: wrap by name (we know the method exists from earlier captures)
    if (typeof proto.resolveSpinResponse === 'function') {
      var orig = proto.resolveSpinResponse;
      proto.resolveSpinResponse = function () {
        try {
          var arg = arguments[0];
          if (arg && Array.isArray(arg.plate)) {
            send({ ts: Date.now(), method: 'resolveSpinResponse', plate: arg });
          }
        } catch (e) {}
        return orig.apply(this, arguments);
      };
      wrappedName = 'resolveSpinResponse';
    } else {
      // Fallback: scan all methods, dispatch on plate-shape arg
      Object.getOwnPropertyNames(proto).forEach(function (mname) {
        if (mname === 'constructor') return;
        var fn;
        try { fn = proto[mname]; } catch (e) { return; }
        if (typeof fn !== 'function') return;
        proto[mname] = function () {
          try {
            for (var i = 0; i < arguments.length; i++) {
              var a = arguments[i];
              if (a && Array.isArray(a.plate)) {
                send({ ts: Date.now(), method: mname, plate: a });
                break;
              }
            }
          } catch (e) {}
          return fn.apply(this, arguments);
        };
      });
      wrappedName = 'fallback-scan';
    }

    console.log(TAG, 'Board wrapped via', wrappedName);
  }, 500);

  /* ---------- 4. Manual debug helpers ---------- */
  window.__sah = {
    sendTest: function () { send({ ts: Date.now(), method: 'manual', plate: { plate: [] } }); },
    host: function () { return plateHost; },
  };

  console.log(TAG, 'installed; polling for Board...');
})();
