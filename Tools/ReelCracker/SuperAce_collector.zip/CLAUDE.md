# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Context

This is a reverse-engineering / analysis workspace for the **SuperAce** online slot game. The primary artifact is `data.txt` — a Cocos Creator 3.x JavaScript bundle captured via mitmproxy (`mitmweb`), containing ~19,700 lines of obfuscated, minified game logic.

Network traffic (spin API requests/responses) is also captured via mitmweb and is the main source of runtime data.

## File

**`data.txt`** (887 KB) — single `System.register("chunks:///game.js", ...)` bundle. All variables are hex-obfuscated (`_0x2d52cd`, etc.). Key modules identified by `_RF.push({}, "<uuid>", "<ClassName>")` markers:

| Line | Module | Description |
|------|--------|-------------|
| 171 | `AudioManager` | Audio singleton; detects Chinese locale for voice selection |
| 4886–6872 | protobufjs | Full protobuf runtime embedded (Field, Type, Namespace, Root, etc.) |
| 8459–10067 | State machine | 13 states: `CheckState` → `SpinState` → `StopSpinState` → `GetRewardingState` → `RoundEndState`, etc. |
| 10092 | `GameDefine` | Enums, `FirstPlate` (static opening board), `DemoData` (two example spin results), game constants |
| 10297 | `SlotSymbol` | Individual symbol node logic |
| 10910 | `GameConst` | **Anti-piracy domain check** + timing arrays + `_0x4e2737()` (force-close) |
| 11088 | `Wheel` | Per-column rolling logic; receives symbol IDs from server on stop |
| 11808 | `EffectViewEx` | Win effect orchestration; `SetOdds([6,6,10,20,30])` → Big/Mega/Super thresholds |
| 12037 | `Board` | Main board controller; owns 5 `Wheel` instances; `resolveSpinResponse()` ingests server plate data |
| 13264+ | Obfuscated modules | String-protection / anti-debug helpers |

## Board Architecture

- **Grid**: 5 columns × 4 rows (server-authoritative)
- **Symbol spacing**: 125 px horizontal (`0x7d`), 154 px vertical (`0x9a`)
- **No reel strips in client** — spinning visuals are `Math.random()` placeholders; actual landing symbols come from server `plate` response
- **Reels 1 & 5** (idx 0, 4) have special `symbolFunc` handling for `Bonus` scatter prefabs

## Server Response Schema

The spin response (`.plate[]`) structure decoded from `DemoData`:

```js
{
  plate: [{                        // array: 1 entry = normal spin, >1 = Free Game rounds
    column: [                      // always 5 columns
      {
        row: ["Symbol5", ...],     // always 4 symbols, top→bottom
        isGold: [0, 0, 0, 0]      // per-row: 0=none, 1=Joker border, 2=BigJoker border,
                                   //          101=Joker solid, 102=BigJoker solid
      }
    ],
    isBonus: true,                 // present when Bonus triggered Free Game
    totalFreeSpin: 10,             // cumulative FG count
    combo: [{                      // cascade chain (may be empty)
      change: [{ symbol, row, column, isGold, lastGold }],  // cells that changed
      award: [{
        symbol: "Symbol6",
        block: [{ row, column }],  // winning positions (0-indexed; column omitted = col 0, row omitted = row 0)
        win: 1,                    // payout in bet units
        bonus: 1,                  // FG bonus spins added
        maxLen: 5                  // longest winning cluster
      }],
      win: 1,                      // total win this cascade (× betValue for display)
      comboBonus: 1                // cascade multiplier
    }],
    win: 77                        // total win this plate round (× betValue)
  }]
}
```

Symbol names: `Symbol1`–`Symbol8`, `Bonus` (triggers FG), `Joker` (wild), `BigJoker` (super wild).

## Win Effect Thresholds

`SetOdds([6, 6, 10, 20, 30])` — win / bet ratio needed:
- ≥ 10× → **BIG WIN**
- ≥ 20× → **MEGA WIN**
- ≥ 30× → **SUPER WIN**

## Anti-Piracy Note

`GameConst` (L10910) contains an XHR domain check (`_0x4e2737` closes the window if the domain is not whitelisted). The authorized domain is encoded as byte arithmetic across `_0x694d02` and `_0x15918e` arrays.
