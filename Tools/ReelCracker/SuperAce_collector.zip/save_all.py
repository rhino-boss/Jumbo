"""mitmproxy script: capture SuperAce spins as JSONL.

- Injects inject_hook.js into application.244af.js so the running game posts
  plaintext spin results back through mitmproxy.
- Each spin -> one line in captured/spins.jsonl with summary + full plate.
- Counter persists in captured/.spin_counter so restarts don't collide.
"""

import os
import time
import json
import struct
from mitmproxy import http
from urllib.parse import urlparse

# ---- paths ---------------------------------------------------------------
ROOT = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else "."
OUT = os.path.join(ROOT, "captured")
SPIN_DIR = os.path.join(OUT, "spins")
JSONL_PATH = os.path.join(OUT, "spins.jsonl")
COUNTER_PATH = os.path.join(OUT, ".spin_counter")
INJECT_FILE = os.path.join(ROOT, "inject_hook.js")

# ---- behaviour toggles ---------------------------------------------------
INJECT_TARGET = "application.244af.js"
PLATE_LOG_PATH = "/__plate_log/"
TARGETS = ["tadagaming.com"]
SAVE_TYPES = ["javascript", "octet-stream", "json"]
# Set True if you also want the encrypted spin .bin files (forensic / cipher work).
SAVE_RAW_SPINS = False
# Print every Nth spin to keep logs sane during long auto-spin sessions.
LOG_EVERY = 1

# ---- mutable state -------------------------------------------------------
_inject_cached = [None]
_counter = [0]
_last_req_bet = [None]  # (bet_value, ts) extracted from the most recent spin request
_init_done = [False]


# ---- helpers -------------------------------------------------------------
def _init():
    if _init_done[0]:
        return
    os.makedirs(OUT, exist_ok=True)
    try:
        with open(COUNTER_PATH, "r") as f:
            _counter[0] = int(f.read().strip())
    except Exception:
        _counter[0] = 0
    print(f"[INIT] spin counter = {_counter[0]}, jsonl = {JSONL_PATH}")
    _init_done[0] = True


def _save_counter():
    try:
        with open(COUNTER_PATH, "w") as f:
            f.write(str(_counter[0]))
    except Exception as e:
        print(f"[ERR] counter save: {e}")


def _inject_bytes() -> bytes:
    if _inject_cached[0] is None:
        try:
            with open(INJECT_FILE, "rb") as f:
                _inject_cached[0] = f.read()
        except FileNotFoundError:
            print(f"[INJECT] WARNING: {INJECT_FILE} not found")
            _inject_cached[0] = b""
    return _inject_cached[0]


def _cors_headers():
    return {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST,GET,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
    }


def _extract_bet_from_req(body: bytes):
    """Best-effort: scan a spin request protobuf for the bet double.
    Layout in observed 76B requests: 12 12 09 <8-byte LE double> ...
    Returns float or None.
    """
    if not body or len(body) < 13:
        return None
    # Look for the pattern '12 12 09' then read 8 bytes as double
    for off in range(0, min(len(body) - 11, 16)):
        if body[off] == 0x12 and body[off + 2] == 0x09:
            try:
                return struct.unpack("<d", body[off + 3 : off + 11])[0]
            except Exception:
                return None
    return None


# ---- mitmproxy hooks -----------------------------------------------------
def request(flow: http.HTTPFlow):
    _init()

    # Plate-log endpoint: intercept before forwarding.
    if PLATE_LOG_PATH in flow.request.path:
        if flow.request.method == "OPTIONS":
            flow.response = http.Response.make(204, b"", {
                **_cors_headers(),
                "Access-Control-Max-Age": "86400",
            })
            return

        body = flow.request.content or b""
        if not body:
            flow.response = http.Response.make(200, b'{"ok":true}', _cors_headers())
            return

        try:
            payload = json.loads(body)
        except Exception as e:
            print(f"[ERR] plate parse: {e}")
            flow.response = http.Response.make(400, b'{"err":"bad_json"}', _cors_headers())
            return

        plate_obj = payload.get("plate")
        if not isinstance(plate_obj, dict) or not isinstance(plate_obj.get("plate"), list):
            flow.response = http.Response.make(200, b'{"ok":true,"skip":1}', _cors_headers())
            return

        plate_list = plate_obj["plate"]

        # ---- summary stats ----
        total_win = 0.0
        for p in plate_list:
            try:
                total_win += float(p.get("win") or 0)
            except Exception:
                pass
        is_bonus = any(bool(p.get("isBonus")) for p in plate_list)
        total_fg = 0
        for p in plate_list:
            try:
                v = int(p.get("totalFreeSpin") or 0)
                if v > total_fg:
                    total_fg = v
            except Exception:
                pass
        plate_count = len(plate_list)
        combo_total = sum(len(p.get("combo") or []) for p in plate_list)

        # latest bet from the most recent spin request (within 30s)
        bet = None
        if _last_req_bet[0] and (time.time() - _last_req_bet[0][1]) < 30:
            bet = _last_req_bet[0][0]

        _counter[0] += 1
        n = _counter[0]
        ts = payload.get("ts") or int(time.time() * 1000)

        record = {
            "n": n,
            "ts": ts,
            "bet": bet,
            "win": round(total_win, 6),
            "is_bonus": is_bonus,
            "total_fg": total_fg,
            "plate_count": plate_count,
            "combo_total": combo_total,
            "method": payload.get("method", ""),
            "plate": plate_obj,
        }

        with open(JSONL_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
        _save_counter()

        if n % LOG_EVERY == 0:
            bet_str = f"bet={bet:.2f} " if isinstance(bet, (int, float)) else ""
            fg_str = f" FG={total_fg}" if is_bonus else ""
            print(f"[SPIN #{n:05d}] {bet_str}win={total_win:.2f} plates={plate_count} combos={combo_total}{fg_str}")

        flow.response = http.Response.make(200, b'{"ok":true}', _cors_headers())
        return


def response(flow: http.HTTPFlow):
    _init()
    url = flow.request.url
    ct = flow.response.headers.get("content-type", "")
    status = flow.response.status_code

    # ---- inject hook into the early-loading JS ----
    if INJECT_TARGET in url and "javascript" in ct and status == 200:
        hook = _inject_bytes()
        if hook:
            original = flow.response.content or b""
            flow.response.content = original + b"\n;\n" + hook
            flow.response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
            flow.response.headers["Pragma"] = "no-cache"
            flow.response.headers.pop("ETag", None)
            flow.response.headers.pop("Last-Modified", None)
            print(f"[INJECT] appended {len(hook)}B hook to {url}")

    if not any(t in url for t in TARGETS):
        return
    if status != 200:
        return
    if not any(t in ct for t in SAVE_TYPES):
        return

    is_spin = "/fullhouse/req" in url and "octet-stream" in ct

    if is_spin:
        req_bytes = flow.request.content or b""
        bet = _extract_bet_from_req(req_bytes)
        if bet is not None:
            _last_req_bet[0] = (bet, time.time())

        if SAVE_RAW_SPINS:
            os.makedirs(SPIN_DIR, exist_ok=True)
            res_bytes = flow.response.content or b""
            n = _counter[0] + 1
            base = f"spin_{n:05d}_{len(res_bytes)}B"
            with open(os.path.join(SPIN_DIR, base + "_req.bin"), "wb") as f:
                f.write(req_bytes)
            with open(os.path.join(SPIN_DIR, base + "_res.bin"), "wb") as f:
                f.write(res_bytes)
        return

    # other static assets
    parsed = urlparse(url)
    path_parts = parsed.path.strip("/").split("/")
    filename = path_parts[-1].split("?")[0] or "index"
    if not filename or "." not in filename:
        filename = filename + ".bin"
    prefix = "_".join(path_parts[:-1])[-60:].replace("/", "_")
    safe_name = f"{prefix}__{filename}" if prefix else filename
    filepath = os.path.join(OUT, safe_name)
    with open(filepath, "wb") as f:
        f.write(flow.response.content)
